/****************************************************************************
 * Pharos - A Real-Time Secure Operating System                             *
 * Copyright 2020 Pedro Macara and Filipe Monteiro                          *
 *                                                                          *
 * Licensed under the Apache License, Version 2.0 (the "License");          *
 * you may not use this file except in compliance with the License.         *
 * You may obtain a copy of the License at                                  *
 *                                                                          *
 *     http://www.apache.org/licenses/LICENSE-2.0                           *
 *                                                                          *
 * Unless required by applicable law or agreed to in writing, software      *
 * distributed under the License is distributed on an "AS IS" BASIS,        *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. *
 * See the License for the specific language governing permissions and      *
 * limitations under the License.                                           *
 *                                                                          *
 ****************************************************************************/


#ifndef PHAROS_V8A_DECLARATIONS_H
#define	PHAROS_V8A_DECLARATIONS_H

#include <pharos/hal/hal.h>
#include <pharos/hal/cpu/declarations.h>
#include <pharos/hal/cpu/conf.h>


/**
 * Calculate the correct size of the shared stack for dynamically created threads.
 * Must be the next multiple of 4 KiB of the original stack size and not below 4 KiB 
 */
#define PHAROS_SHARED_STACK_CORRECT_SIZE(size)      MAX_MACRO(VALUE_4KiB , VALUE_4KiB * PHAROS_CEILING(size , VALUE_4KiB))


/**
 * Alignment of the shared stack. Must be aligned to an MMU page
 */
#define PHAROS_DYNAMIC_STACK_ALIGN(size)   VALUE_4KiB


/* PHAROS_V8A_DECLARATIONS_H */
#endif	
