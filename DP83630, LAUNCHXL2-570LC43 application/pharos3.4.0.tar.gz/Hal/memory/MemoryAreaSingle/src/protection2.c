/****************************************************************************
 * Pharos - A Real-Time Secure Operating System                             *
 * Copyright 2020 Pedro Macara and Filipe Monteiro                          *
 *                                                                          *
 * Licensed under the Apache License, Version 2.0 (the "License");          *
 * you may not use this file except in compliance with the License.         *
 * You may obtain a copy of the License at                                  *
 *                                                                          *
 *     http://www.apache.org/licenses/LICENSE-2.0                           *
 *                                                                          *
 * Unless required by applicable law or agreed to in writing, software      *
 * distributed under the License is distributed on an "AS IS" BASIS,        *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. *
 * See the License for the specific language governing permissions and      *
 * limitations under the License.                                           *
 *                                                                          *
 ****************************************************************************/


#include <pharos/kernel/object/declarations.h>
#include <pharos/kernel/object/protection.h>
#include <pharos/hal/boardApi.h>
#include <pharos/hal/cpu/linker.h>
#include <pharos/kernel/interrupt/interrupt.h>
#include <pharos/kernel/partition/partition.h>
#include <pharos/kernel/core/coreconfinline.h>
#include <pharos/kernel/core/coreinlines.h>
#include <pharos/hal/cpu/sections.h>




/* initialize the kernel memory protection information */
RONLY_SECTION const EnvMemoryProtection pharosVKernelMemProtection = {
    .startAddress[0] = &pharosKernelStart ,
    .endAddress[0] = &pharosKernelEnd
};
